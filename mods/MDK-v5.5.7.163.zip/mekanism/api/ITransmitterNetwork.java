package mekanism.api;

public interface ITransmitterNetwork
{
	public void tick();
	
	public int getSize();
}
