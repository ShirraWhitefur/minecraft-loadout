package appeng.api.me.items;

/**
 * Some basic actions you can perform on Patterns.
 */
public interface IMEPatternItem {
	boolean isEncoded();
	String Type();
}
